package com.example.bicyclecrud.ui.screen

class BicycleAddScreen {
}